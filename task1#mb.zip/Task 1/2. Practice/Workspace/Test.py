

# Import cardinal,pyc

import cardinal


if __name__ == '__main__':
	cardinal.main()

