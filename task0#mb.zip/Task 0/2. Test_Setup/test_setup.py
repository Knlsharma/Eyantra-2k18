
# Import module
import cardinal


# Main function
if __name__ == '__main__':

	cardinal.main()

